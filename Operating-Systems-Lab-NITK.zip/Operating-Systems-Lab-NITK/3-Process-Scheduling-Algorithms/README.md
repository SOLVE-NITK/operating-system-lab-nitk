## Introduction (Round 0)

<br>

<b>Discipline | <b>Engineering
:--|:--|
<b> Lab | <b>  Operating Systems
<b> Experiment| <b> 3. Process Scheduling Algorithms

<h5> About the Experiment : </h5>
Objective of scheduling in an operating system is to increase the performance of the system. This experiment helps to understand the execution of a set of processes through various scheduling algorithms like First-Come, First-Served Scheduling, Shortest-Job-First Scheduling, Shortest-remaining-time-first scheduling, Priority Scheduling and Round-Robin Scheduling algorithm.

<b>Name of Developer | <b> Dr. Mohit P. Tahiliani
:--|:--|
<b> Institute | <b> National Institute of Technology Karnataka, Surathkal
<b> Email id| <b> tahiliani@nitk.edu.in
<b> Department | Computer Science & Engineering

#### Contributors List
