1. Operating System Concepts - by Silberschatz, Galvin, Gagne<br>
