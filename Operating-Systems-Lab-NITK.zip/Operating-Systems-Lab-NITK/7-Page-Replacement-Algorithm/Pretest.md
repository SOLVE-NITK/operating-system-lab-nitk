Q 1. Page Replacement Algorithms are used in Virtual Memory Management in Operating System. Say True/False
a. False
b. True

Ans: b

Q 2. Which of the following page replacement algorithms suffers from Belady’s Anomaly?
a. Optimal replacement
b. LRU
c. FIFO
d. Both optimal replacement and FIFO

Ans: c

Q 3. What is First In First Out(FIFO) Algorithm?
a. Page will not be used for the longest duration of time in future reference will be replaced.
b. Oldest page in main memory is selected for replacement
c. Page which is recently used is replaced
d. None of the above

Ans: b

Q 4. What is Optimal Page Replacement Algorithm?
a. Page will not be used for the longest duration of time in future reference will be replaced.
b. Page which is recently used is replaced
c. Oldest page in main memory is selected for replacement
d. None of the above

Ans: a

Q 5. What is Lease Recently Used Algorithm?
a. Page will not be used for the longest duration of time in future reference will be replaced.
b. Oldest page in main memory is selected for replacement
c. Page which is recently used is replaced
d. None of the above

Ans: c
