#### Procedure to run the Simulator is as follows:
* Enter the reference string. Page number must be single character. Dont use any seperator. <br> ex. if reference string is [1,2,3,4,0,a,b,c] then you should provide input as: "12340abc" withous double quotes.</li>
* Enter the number of frames of main memory.</li>
* Choose appropriate algorithm for the simulation(Optimal Page Replacement, Last Recently    Used, First InFirst Out).</li>
* Click Simulate Button to see the Visual Simulation of Page Replacement step by step</li>
