1. https://www.geeksforgeeks.org/page-replacement-algorithms-in-operating-systems/
2. https://www.sanfoundry.com/operating-system-mcqs-virtual-memory-page-replacement-algorithms-1/
