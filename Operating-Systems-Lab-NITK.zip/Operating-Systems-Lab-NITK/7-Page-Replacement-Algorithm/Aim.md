To explain Page Replacement Algorithms which are important part of Virtual Memory Management in OS aims to reduce number of page faults by simulating following algorithms:
1. First In First Out (FIFO)
2. Optimal Page replacement
3. Least Recently Used
