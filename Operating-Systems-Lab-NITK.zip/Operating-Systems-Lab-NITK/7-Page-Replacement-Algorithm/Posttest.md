Q 1.  Optimal Page – replacement algorithm is difficult to implement, because ____________
a. it requires a lot of information
b. it requires future knowledge of the reference string
c. it requires a lot of memory
d. it is extremely expensive

Ans: b

Q 2. Assume that there are 3 page frames which are initially empty. If the page reference string is 7, 0, 1, 2, 0, 3, 0, 4, 3, 0 then the number of page faults using the Least Recently Used is.
a. 6
b. 7
c. 8
d. 9

Ans: a

Q 3. Assume that there are 3 page frames which are initially empty. If the page reference string is 1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5, then the number of page faults using the optimal replacement policy is__________.
a. 4
b. 5
c. 7
d. 8

Ans: 7

Q 4. Assume that there are 4 page frames which are initially empty. If the page reference string is 7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2  then the number of page faults using the optimal replacement policy is__________.
a. 4
b. 5
c. 7
d. 6

Ans: d

Q 5.The reason for using the Least Frequently Used page replacement algorithm is :
a. An actively used page should have a large reference count
b. A less used page has more chances to be used again
c. It is extremely efficient and optimal
d. All of the above

Ans: a
