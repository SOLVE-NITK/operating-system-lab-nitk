## Storyboard (Round 2)

Experiment 2: Fundamentals of System Calls 

### 1. Story Outline:

### 2. Story:

#### 2.1 Set the Visual Stage Description:

#### 2.2 Set User Objectives & Goals:

#### 2.3 Set the Pathway Activities:

##### 2.4 Set Challenges and Questions/Complexity/Variations in Questions:

##### 2.5 Allow pitfalls:

##### 2.6 Conclusion:

##### 2.7 Equations/formulas: NA

### 3. Flowchart 4

### 4. Mindmap:

### 5. Storyboard :
