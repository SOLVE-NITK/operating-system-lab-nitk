## <b> Pre-test</b>
#### Please attempt the following questions
<br>
Q 1. System calls are executed in user mode.<br>
a. True<br>
<b>b. False</b><br><br>

Q 2. Which of the following is not a valid Unix system call ?<br>
a. fork()<br>
b. getpid()<br>
c. write()<br>
<b>d. console()</b><br>

Q 3. User can run some privileged instructions in user mode.<br>
<b>a. False</b><br>
b. True<br>

Q 4. When system boots up, it always starts in _________.<br>
a. User mode<br>
<b>b. Kernel mode</b><br>
c. Kernel mode only if safe boot is selected<br>
d. None of the above<br>

Q 5. Which of the following is/are type of information maintenance system call ?<br>
a. ioctl()<br>
b. chmod()<br>
<b>c. getpid()</b><br>
d. All of the above<br>
