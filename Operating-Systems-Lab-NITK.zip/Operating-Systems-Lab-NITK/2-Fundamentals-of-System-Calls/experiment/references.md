1. Operating System Concepts - by Silberschatz, Galvin, Gagne<br>

2. <a href="https://www.youtube.com/watch?v=z3Nw5o9dS7Q&list=PLsylUObW5M3CAGT6OdubyH6FztKfJCcFB">Lecture 1: Introduction to UNIX System Calls Part 1</a></br>

3. <a href="https://www.youtube.com/watch?v=PsUEyhpi7cA">Lecture 2: Introduction to UNIX System Calls Part 2</a></a><br>
