## Post test
<br>
Q 1. open(), read(), write() functions are file management related system calls in Unix.<br>
<b>a. True</b><br>
b. False<br><br>

Q 2. System calls are usually invoked by using<br>
a. Polling<br>
b. A privileged instruction<br>
<b>c. A software interrupt</b><br>
d. An indirect jump<br>

Q 3. Which of the following system calls does not return control to the calling point, on termination ?<br>
a. Fork<br>
<b>b. Exec</b><br>
c. Ioctl<br>
d.	Longjmp<br>

Q 4. Which of the following calls never returns an error ?<br>
a. open()<br>
b. fork()<br>
c. getpid()<br>
<b>d. exec()</b><br>

Q 5. If a thread invokes the exec system call, then<br>
a. Only the exec executes as a separate process.<br>
b. The exec is ignored as it is invoked by a thread.<br>
<b>c. The program specified in the parameter to exec will replace the entire process</b><br>
d. None of the above<br><br>
