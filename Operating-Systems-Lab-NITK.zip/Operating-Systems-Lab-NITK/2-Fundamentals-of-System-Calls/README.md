## Introduction (Round 0)

<br>

<b>Discipline | <b>Engineering
:--|:--|
<b> Lab | <b>  Operating Systems
<b> Experiment| <b> 2. Fundamentals of System Calls

<h5> About the Experiment : </h5>
Objective of this experiment is to understand the working of system calls. A system call is a way for programs to interact with the operating system. The theory part gives the information about types of system calls and various operations used to invoke system calls. 

<b>Name of Developer | <b> Dr. Mohit P. Tahiliani
:--|:--|
<b> Institute | <b> National Institute of Technology Karnataka, Surathkal
<b> Email id| <b> tahiliani@nitk.edu.in
<b> Department | Computer Science & Engineering

#### Contributors List
