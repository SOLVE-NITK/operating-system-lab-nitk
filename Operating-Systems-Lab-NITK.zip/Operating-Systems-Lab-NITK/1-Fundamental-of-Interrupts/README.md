## Introduction (Round 0)

<br>

<b>Discipline | <b>Engineering
:--|:--|
<b> Lab | <b>  Operating Systems
<b> Experiment| <b> 1. Fundamentals of Interrupts

<h5> About the Experiment : </h5>
Understanding what the CPU does when an interrupt occurs is a key point towards understanding how operating systems works. The purpose of the experiment is to understand the working of interrupts.  

<b>Name of Developer | <b> Dr. Mohit P. Tahiliani
:--|:--|
<b> Institute | <b> National Institute of Technology Karnataka, Surathkal
<b> Email id| <b> tahiliani@nitk.edu.in
<b> Department | Computer Science & Engineering

#### Contributors List
