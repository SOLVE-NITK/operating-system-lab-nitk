1. Operating System Concepts - by Silberschatz, Galvin, Gagne<br>

2. <a href="https://www.tutorialspoint.com/embedded_systems/es_interrupts.htm">https://www.tutorialspoint.com/embedded_systems/es_interrupts.htm</a></br>

3. <a href="https://brainly.in/question/1587087">https://brainly.in/question/1587087</a><br>

4. <a href="http://faculty.salina.k-state.edu/tim/ossg/Introduction/OSworking.html">http://faculty.salina.k-state.edu/tim/ossg/Introduction/OSworking.html</a>
