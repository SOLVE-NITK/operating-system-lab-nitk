## Post test
<br>
Q 1. The time between the receiver of an interrupt and its service is ______.<br>
<b>a. Interrupt latency</b><br>
b. Cycle time<br>
c. Switching time<br>
d. None of the above<br><br>

Q 2. Following are the interrupt sources handled by the computer.<br>
	i. Interrupt from CPU temperature sensor (raises interrupt if CPU temperature is too high)<br>
	ii. Interrupt from Mouse (raises interrupt if the mouse is moved or a button is pressed)<br>
	iii. Interrupt from Keyboard (raises interrupt when a key is pressed or released)<br>
	iv. Interrupt from Hard Disk (raises interrupt when a disk read is completed)<br>
	Which one of these will be handled at the HIGHEST priority?<br>
a. Interrupt from Hard Disk<br>
b. Interrupt from Mouse<br>
c. Interrupt from Keyboard<br>
<b>d. Interrupt from CPU temperature sensor</b><br>

Q 3. The signal sent to the device from the processor to the device after receiving an interrupt is<br>
<b>a. Interrupt-acknowledge</b><br>
b. Return signal<br>
c. Service signal<br>
d. Permission signal<br>

Q 4. Which table handle stores the addresses of the interrupt handling subroutines? <br>
a. Vector table<br>
b. Symbol link table<br>
<b>c. Interrupt-vector table</b><br>
d. None of the above<br>

Q 5. A single Interrupt line can be used to service n different devices?<br>
a. False<br>
<b>b. True</b><br>
