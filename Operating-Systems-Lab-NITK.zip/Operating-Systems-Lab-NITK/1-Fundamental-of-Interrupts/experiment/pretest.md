## <b> Pre-test</b>
#### Please attempt the following questions

<br>
Q 1. A processor needs software interrupt to<br>
a. test the interrupt system of the processor<br>
b. implement coroutines<br>
<b>c. obtain system services which need execution of privileged instructions</b><br>
d. return from subroutine<br><br>

Q 2. Interrupts form an important part of _____ systems.<br>
a. Batch processing<br>
b. Multitasking<br>
c. Multi-user<br>
<b>d. Real-time processing</b><br>

Q 3. An interrupt that can be temporarily ignored is<br>
a. System heap<br>
<b>b. Maskable interrupt</b><br>
c. Non-maskable interrupt<br>
d. High priority interrupt<br>

Q 4. The return address from the interrupt-service routine is stored on the<br>
a. System heap<br>
b. Processor register<br>
c. No resource can be forcibly removed from a process holding it<br>
<b>d. Processor stack</b><br>

Q 5. In case of polling, the controller keeps monitoring the flags or signals one by one for all devices and provides service to components in need.<br>
<b>a. True</b><br>
b. False<br>
