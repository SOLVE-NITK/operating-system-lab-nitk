##### These procedure steps will be followed on the simulator
<br>

<ul style="text-align:justify;">
<li>The simulation demonstrates the working of interrupt by operating system.</li>
<li>In the simulation, click on "Next" button to move to the next step till the end of the simulation.</li>
<li>When an interrupt occurs, the currently executing process is pre-empted and interrupt is served.</li>
<li>After serving the interrupt, the operating system continues the execution of previously pre-empted process.</li>
</ul>
