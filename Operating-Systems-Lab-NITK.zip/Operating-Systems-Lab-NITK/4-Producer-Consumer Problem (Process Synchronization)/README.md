## Introduction (Round 0)

<br>

<b>Discipline | <b>Engineering
:--|:--|
<b> Lab | <b>  Operating Systems
<b> Experiment| <b> 4. Producer-Consumer Problem (Process Synchronization)

<h5> About the Experiment : </h5>
To understand the working of Producer-Consumer Problem or Bounded Buffer problem. This is used for process synchronization.

<b>Name of Developer | <b> Dr. Mohit P. Tahiliani
:--|:--|
<b> Institute | <b> National Institute of Technology Karnataka, Surathkal
<b> Email id| <b> tahiliani@nitk.edu.in
<b> Department | Computer Science & Engineering

#### Contributors List
