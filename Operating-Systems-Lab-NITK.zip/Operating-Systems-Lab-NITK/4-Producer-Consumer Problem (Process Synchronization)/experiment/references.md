<ol style="text-align: justify;">
<li> Operating System Concepts - by Silberschatz, Galvin, Gagne</li>

<li> <a href="https://www.youtube.com/watch?v=UjuVVj37wsE&list=PLsylUObW5M3CAGT6OdubyH6FztKfJCcFB&index=25">Multiple producer-multiple consumer queue, Semaphore</a></li>

<li> <a href="https://afteracademy.com/blog/the-producer-consumer-problem-in-operating-system">The producer-consumer problem in Operating System</a></li>
</ol>
