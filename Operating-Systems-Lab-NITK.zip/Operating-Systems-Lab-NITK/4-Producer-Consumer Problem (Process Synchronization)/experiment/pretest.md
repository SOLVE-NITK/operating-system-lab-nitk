## <b> Pre-test</b>
#### Please attempt the following questions
<br>
Q 1. The Producer-Consumer problem is also known as <br>
a. Readers Writers problem<br>
b. Dining Philosophers problem<br>
<b>c. Bounded buffer problem</b><br>
d. None of the above<br><br>

Q 2. Producer-Consumer problem can be solved using semaphore.<br>
a. True<br>
<b>b. False</b><br>

Q 3. Data structure is used to hold the items in Producer-Consumer problem is<br>
a. Stack<br>
b. Tree<br>
c. Linked list<br>
<b>d. Queue</b><br>

Q 4. Consumer can consume multiple data from the buffer at a time.<br>
a. True<br>
<b>b. False</b><br>

Q 5. Inter process communication <br>
a. Allows processes to communicate and synchronize their actions using the same address space<br>
<b>b. Allows processes to communicate and synchronize their actions without using the same address space</b><br>
c. Allows the processes to only synchronize their actions without communication<br>
d. None of the above<br>
