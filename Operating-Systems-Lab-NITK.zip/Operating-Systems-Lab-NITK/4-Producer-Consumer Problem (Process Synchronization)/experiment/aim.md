To understand the working of Producer-Consumer Problem or Bounded Buffer problem. Producer-Consumer Problem is used for process synchronization.
