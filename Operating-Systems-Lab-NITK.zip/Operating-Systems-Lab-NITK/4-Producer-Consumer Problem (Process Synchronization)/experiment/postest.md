## Post test
<br>
Q 1. Producer-Consumer problem without any synchronization mechanism suffers from <br>
<b>a. Data Loss / Inconsistency</b><br>
b. Starvation<br>
c. Deadlock<br>
d. None of the above<br><br>

Q 2. A semaphore is a variable or abstract data type used to control access to a common resource by multiple processes in a concurrent system such as a multitasking operating system.<br>
a. False<br>
<b>b. True</b><br>

Q 3. When multiple processes or threads read and write data items so that the final result depends on the order of execution of instructions in the multiple process is called <br>
a. Mutual exclusion<br>
b. Deadlock<br>
<b>c. Race condition</b><br>
d. None othe above<br>

Q 4. Producer and consumer cannot access buffer at the same time.<br>
<b>a. True</b><br>
b. False<br>
