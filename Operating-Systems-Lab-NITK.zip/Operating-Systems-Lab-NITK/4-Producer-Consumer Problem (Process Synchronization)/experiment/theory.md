### INTRODUCTION<br>

<p style="text-indent:50px; text-align: justify; font-family: verdana;">The Producer-Consumer problem ( Bounded Buffer problem ) is used for synchronization between multiple processes. Sharing system resources by processes in a such a way that, concurrent access to shared data is handled thereby minimizing the chance of inconsistent data. This problem describes two processes, producer and consumer is <b>Process Synchronization</b>. Both the processes share a common fixed size buffer. The job of the producer is to generate the data and store it in the buffer, and the consumer consumes or removes the data  from the buffer one at a time. There are some conditions when the two processes are executing, such as:</p>
<ul style="text-align: justify; font-family: verdana;"> <li>Producer can put the data into the buffer only if it is not full. If the buffer is full then the producer should not be allowed to put the data into the buffer.</li>
<li>Consumer should not be allowed to take the data from the buffer when the buffer is empty.</li>
<li>At the same time, both the processes producer and consumer should not be allowed to access the buffer.</li></ul>

<p style="text-indent:50px; text-align: justify; font-family: verdana;">The problem arises when the producer tries to put the a new item into the completely filled buffer or when the consumer tries to remove an item from the empty buffer. One solution for this problem is to put the producer into sleep mode whenever the buffer is full or put the consumer to sleep when the buffer is empty. That is when the buffer is full, producer awakens the consumer to consume the data from the buffer. Similarly when the buffer is empty, the consumer wakes up the producer and goes to sleep. This may lead to some kind of race conditions. Following code illustrates the Producer-Consumer problem using sleep and wake up system calls. </p>

<center><img src="images/pccode.png"/></br></center></br>

<p style="text-indent:50px; text-align: justify; font-family: verdana;"> This code will cause the problem. Producer and Consumer, both the processes are infinite that means they execute infinitely as their logic is written in while(1) loop where loop condition is always true. Here buffer and count are two common variables used in producer and consumer code. Buffer is used to hold the data i.e. items produced by the producer. Producer produces one item at time if the buffer is not full and puts that item in a buffer. Whenever a producer puts an item in a buffer, it increments the value of the count variable. Later consumer process consumes one item at time from buffer if buffer is not empty and decrements count variable by 1. Producer produces one item at a time and stores it in "itemp" variable. Then it checks whether the buffer is full, if the buffer is full then while loop will keep iterating until the value of count not becomes less than N. This type of waiting is called <b>busy waiting</b>. In the next step, the produced item is stored in a "buffer". Variable "in" is just a counter/position to put the next item in the buffer. Variable "count" is used to keep track of the count of the number of items present in the buffer.</p>


<p style="text-indent:50px; text-align: justify; font-family: verdana;">Consumer first checks if there is any item present in the buffer, while loop checks if the buffer is empty or not. If the buffer is empty then keeps waiting as while loop will not terminate unless count > 0. If the buffer is not empty then the consumer takes one item from the buffer, stores that item in variable "itemc" and decrements count by 1. At last consumer processes/consumes the "itemc". So the problem here lies in the increment and decrement of the "count" variable. CPU cannot execute the statement "count ++" as it is. Statement will be converted to the Assembly language (low level language) and then the CPU executes the Assembly instructions one by one.</p>

<p style="text-align: justify; font-family: verdana;">count++ after converting to assembly -  </p>
<p style="text-indent:250px; text-align: justify;">e1. load Rp, count</p>
<p style="text-indent:250px; text-align: justify;">e2. Inc Rp</p>
<p style="text-indent:250px; text-align: justify;">e3. Store count, Rp</p>

<p style="text-align: justify; font-family: verdana;">count-- after converting to assembly -  </p>
<p style="text-indent:250px; text-align: justify;">d1. load Rq, count</p>
<p style="text-indent:250px; text-align: justify;">d2. Dec Rq</p>
<p style="text-indent:250px; text-align: justify;">d3. Store count, Rq</p>
<p style="text-align: justify; font-family: verdana;">Where e1, e2, e3 and d1, d2, d3 are the steps and Rp and Rq are the CPU registers.</p>

<p style="text-indent:50px; text-align: justify; font-family: verdana;">Now consider the situation when the value of count is 99 and the producer is active. Producer will produce one item and check whether the buffer is full. As Buffer is not full and count is 99, there is one place empty in the buffer. So the producer will put one item in the buffer and continue its execution. But when the producer executes count++ instruction, (See the assembly code of count++) that is producer executes step e1, e2 and gets pre-empted. Note here that buffer is full, count value is 99, Rp became 100 and producer is pre-empted.</p>

<p style="text-indent:50px; text-align: justify;  font-family: verdana;">Now the consumer gets the CPU and starts its execution. It sees that the value of count is 99 and so the buffer is not empty. So the consumer will consume the items from the buffer and when the buffer is empty it will wait for the producer to produce the items. Once the consumer consumes all the items, it will set count = 0.</p>

<p style="text-indent:50px; text-align: justify; font-family: verdana;">Now the consumer gets pre-empted and the producer process continues its execution again. Producer executes the next instruction which is step e3. Notice that Rp was loaded with 99 and INC instruction incremented value of Rp by one so Rp is 100. Step e3 will store the value of register Rp in the count variable. Therefore count will become 100 and the producer process will wait for the consumer process to consume the item. Buffer has only one item but count is showing that buffer is full. This leads to incorrect results and data loss.</p>

<p style="text-indent:50px; text-align: justify; font-family: verdana;">Implementation of the Producer-Consumer problem using sleep and wakeup system call can cause deadlock. One solution to the Producer-Consumer problem is using semaphore. A <b>semaphore</b> is a variable or abstract data type used to control access to a common resource by multiple processes in a concurrent system such as a multitasking operating system.</p>

#### <p  style="font-family: verdana;">Solution to the producer consumer problem using semaphore :</p>
<center><img src="images/pccode2.png"/></center></br>

<p style="text-align: justify; font-family: verdana;">The above pseudo code will guarantee that the parallel execution of these processes will not cause any problem.</p>
