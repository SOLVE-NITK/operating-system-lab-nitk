
// Don't touch the below code

(function() {
  function buildQuiz() {
    // we'll need a place to store the HTML output
    const output = [];

    // for each question...
    myQuestions.forEach((currentQuestion, questionNumber) => {
      // we'll want to store the list of answer choices
      const answers = [];

      // and for each available answer...
      for (letter in currentQuestion.answers) {
        // ...add an HTML radio button
        answers.push(
          `<label>
            <input type="radio" name="question${questionNumber}" value="${letter}">
            ${letter} :
            ${currentQuestion.answers[letter]}
          </label>`
        );
      }

      // add this question and its answers to the output
      output.push(
        `<div class="question"> ${currentQuestion.question} </div>
        <div class="answers"> ${answers.join("")} </div>`
      );
    });

    // finally combine our output list into one string of HTML and put it on the page
    quizContainer.innerHTML = output.join("");
  }

  function showResults() {
    // gather answer containers from our quiz
    const answerContainers = quizContainer.querySelectorAll(".answers");

    // keep track of user's answers
    let numCorrect = 0;

    // for each question...
    myQuestions.forEach((currentQuestion, questionNumber) => {
      // find selected answer
      const answerContainer = answerContainers[questionNumber];
      const selector = `input[name=question${questionNumber}]:checked`;
      const userAnswer = (answerContainer.querySelector(selector) || {}).value;

      // if answer is correct
      if (userAnswer === currentQuestion.correctAnswer) {
        // add to the number of correct answers
        numCorrect++;

        // color the answers green
        //answerContainers[questionNumber].style.color = "lightgreen";
      } else {
        // if answer is wrong or blank
        // color the answers red
        answerContainers[questionNumber].style.color = "red";
      }
    });

    // show number of correct answers out of total
    resultsContainer.innerHTML = `${numCorrect} out of ${myQuestions.length}`;
  }

  const quizContainer = document.getElementById("quiz");
  const resultsContainer = document.getElementById("results");
  const submitButton = document.getElementById("submit");


// Don't touch the above code




// Write your MCQs here --- Start --- --------------------

const myQuestions = [
  {
    question: "The Producer-Consumer problem is also known as ",
    answers: {
		  a: "Readers Writers problem",
		  b: "Dining Philosophers problem",
	    c: "Bounded buffer problem ",
	    d: "None of the above"
    },
    correctAnswer: "c"
  },

  {
    question: "Producer-Consumer problem can be solved using semaphore.",
    answers: {
      a: "True",
      b: "False"
    },
    correctAnswer: "a"
  },

  {
    question: "Data structure is used to hold the items in Producer-Consumer problem is",
    answers: {
		  a: "Stack",
		  b: "Tree",
	    c: "Linked list",
	    d: "Queue"
    },
    correctAnswer: "d"
  },
  {
    question: "Consumer can consume multiple data from the buffer at a time.",
    answers: {
      a: "True",
      b: "False"
    },
    correctAnswer: "b"
  },

  {
    question: "Inter process communication ",
    answers: {
      a: "Allows processes to communicate and synchronize their actions using the same address space",
      b: "Allows processes to communicate and synchronize their actions without using the same address space",
      c: "Allows the processes to only synchronize their actions without communication",
      d: "None of the above"
    },
    correctAnswer: "b"
  }
];


// ---------------------------- End -------------------------------

// display quiz right away
  buildQuiz();

  // on submit, show results
  submitButton.addEventListener("click", showResults);
})();
