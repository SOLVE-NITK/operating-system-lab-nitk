##### These procedure steps will be followed on the simulator
<br>

<p style="text-align:justify;">Simulation is the demonstration of how Producer and consumer do their job of producing and consuming items. </p>
<p style="text-align:justify;">Procedure is as follows:
<ol style="text-align:justify;">
<li> Open the simulation page.</li>
<li> There are two buttons named producer and consumer which does the job of our classical Producer and Consumer.</li>
<li> On click of producer button, one item will be produced and added to buffer.</li>
<li> On click of consumer button one item will be consumed and removed from buffer.</li>
<li> Buffer size is 5 so at most 5 items can be generated and consume at most 5 items.</li>
<li> Click on producer button to produce the items.</li>
<li> Once producer generates 5 items then buffer becomes full and producer has to wait for consumer to consume the item.</li>
<li> Click on consumer button to consume the items.</li>
<li> Once all the items are consumed, consumer cannot perform any action and has to wait for producer to produce items.</li>
<li> You can press producer and consumer buttons in any order.</li>
<li> Simulation is deadlock free as producer and consumer cannot run simultaneously.</li>
</ol>
