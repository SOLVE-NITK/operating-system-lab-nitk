#### Procedure to run the Simulator is as follows:
1. The experiment is designed only for 4 processes and 3 resources.</li>
2. On Simulation page, Enter the details of already allocated resources to process P1</li>
3. Enter the details of maximum resources required by process P1(allocated + need).</li>
4. Click on Submit button.</li>
5. Repeat step 2 to step 4 for remaining 3 processes.</li>
6. Enter the details of currently available resources which can be allocated to process.(Available)</li>
7. Click submit button</li>
8. Just check area below Next button to see the output of steps and observe the updations in table.</li>
9.  Press the Next button to execute the next step. Keep pressing Next button for execution of every step.</li>
10. In the beginning, initial need will be calculated. </li>
11. Then the processes are checked repeatedly if they can be completed with the present available. <br> (meaning in order: Process 1 -> Process 2 -> Process 3 -> Process 4 -> Process 5 -> Process 1 ... and so on until all processes are executed or need of remaining processes is not satisfiable with available resources).</li>
