1. https://www.geeksforgeeks.org/bankers-algorithm-in-operating-system-2/
2. https://www.hackerearth.com/blog/developers/dijkstras-bankers-algorithm-detailed-explaination/
