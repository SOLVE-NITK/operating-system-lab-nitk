Q 1. Banker’s algorithm is a Deadlock______
a. Avoidance and prevention algorithm
b. Detection algorithm
c. Ignorance algorithm
d. Recovery algorithm

Ans. d

Q 2. The data structures available in the Banker’s algorithm are ____________
a. Available
b. Need
c. Allocation
d. All of the above

Ans: d

Q 3. System is in safe state if _____
a. It is possible for all processes to finish executing
b. The system can allocate resources to each process in some order and still avoid a deadlock
c. Both a and b
d. None

Ans: c

Q 4.If system is in safe state then deadlock cannot occur for any sequence of process execution.
a. True
b. False

Ans: a

Q 5. What is the drawback of banker’s algorithm?
a. In advance processes rarely know that how much resource they will need
b. The number of processes changes as time progresses
c. Resource once available can disappear
d. All of the above

Ans: d
