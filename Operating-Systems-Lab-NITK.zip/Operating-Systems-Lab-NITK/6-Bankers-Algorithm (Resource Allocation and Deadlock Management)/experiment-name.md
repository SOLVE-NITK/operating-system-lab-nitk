## 	Bankers Algorithm (Resource Allocation and Deadlock Management)
