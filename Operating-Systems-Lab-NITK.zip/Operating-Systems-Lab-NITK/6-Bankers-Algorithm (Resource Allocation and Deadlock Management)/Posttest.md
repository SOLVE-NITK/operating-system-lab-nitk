Q 1. Allocation: is a 2D array of size 'n*m' representing
a. maximum demand of each process for resources in the system
b. number of resources of each type currently allocated to processes
c. number of available resources of each type
d. how many instances of each resource is allocated to each the process

Ans: d

Q 2. Need: is a 2D array of size 'n*m' representing
a. maximum demand of each process for resources in the system
b. number of resources of each type currently allocated to processes
c. number of available resources of each type
d. how many instances of each resource is allocated to each the process

Ans: b

Q 3. Maximum: is a 2D array of size 'n*m' representing
a. number of resources of each type currently allocated to processes
b. number of available resources of each type
c. maximum demand of each process for resources in the system
d. how many instances of each resource is allocated to each the process

Ans: d

Q 4. Available: is a 1D array representing
a. number of available resources of each type
b. number of resources of each type currently allocated to processes
c. maximum demand of each process for resources in the system
d. how many instances of each resource is allocated to each the process

Ans: a

Q 5. How to calculate need for each of the resource?
a. Need = Maximum + Available
b. Need = Allocation - Available
c. Need = Maximum - Available
d. Need = Available - Maximum

Ans: c

Q 6. If Need < Available, then System is in safe state. Say True/False
a. True
b. False

Ans: b
