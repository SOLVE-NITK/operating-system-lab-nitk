Q 1. In Multitasking Operating system, synchronization problems occur because of
a. Critical Section
b. Race Condition
c. Preemption
d. All of the above

Ans: d

Q 2.A deadlock happens in operating system when two or more processes are waiting for some resource that is held by the other process to complete their execution. Say True/False
a. False
b. True

Ans: b

Q 3. Which are the conditions that hold, if there id deadlock
a. Mutual Exclusion
b. Hold and Wait
c. Non Preemption and Circular Wait
d. All of the above

Ans: d

Q 4. Strategies to handle deadlock
a. Deadlock Avoidance and prevention
b. Detection and Recovery
c. Deadlock Ignorance
d. All of the above

Ans: d

Q 5. Example for Deadlock Avoidance Algorithm
a. Round-Robin algorithm
b. Elevator algorithm
c. Banker’s algorithm
d. Ostrich Algorithm

Ans. c

Q 6. The dining – philosophers is the classic synchronization problem that explains about deadlock. Say True/False
a. 	True
b. False

Ans: a
