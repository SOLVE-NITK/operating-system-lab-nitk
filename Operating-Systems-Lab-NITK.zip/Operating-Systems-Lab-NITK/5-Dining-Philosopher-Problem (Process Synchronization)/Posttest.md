Q 1. The dining – philosophers problem has:
a. 	4 philosophers and 5 chopsticks
b. 	3 philosophers and 5 chopsticks
c. 	6 philosophers and 5 chopsticks
d. 	5 philosophers and 5 chopsticks

Ans: d

Q 2. What is the necessary condition for a philosopher to eat
a. A philosopher can use only left chopstick
b. A philosopher can use only right chopstick
c. A philosopher must use both left and right chopsticks
d. None of the above

Ans: c

Q 3. A philosopher can be in either of 2 states: Thinking or Eating. Say True/False
a. False
b. True

Ans: b

Q 4. Deadlock occurs in dining philosopher's problem,
a. When one philosopher wants to eat at a time
b. When two philosophers want to eat at a time
c. when three philosophers want to eat at time
d. When all five philosophers want to eat a time

Ans: d

Q 5. In Simulator, thinking state of a philosopher is represented in color
a. Green
b. Yellow
c. Red
d. None

Ans: c

Q 6. In Simulator, eating state of a philosopher is represented in color
a. Red
b. Green
c. Yellow
d. None

Ans: b

Q 7. In Simulator, a philosopher waiting for chopstick represented in color
a. Yellow
b. Red
c. Green
d. None

Ans: a

Q 9. A solution to the Dining Philosophers Problem which avoids deadlock is:
a. Ensure that all philosophers pick up the left fork before the right fork
b. Ensure that all philosophers pick up the right fork before the left fork
c. Ensure that one particular philosopher picks up the left fork before the right fork, and that all other philosophers pick up the right fork before the left fork
d. None

Ans: c
