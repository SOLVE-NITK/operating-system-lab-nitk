1. https://www.studytonight.com/operating-system/dining-philosophers-problem
2. http://www.cs.rpi.edu/academics/courses/fall04/os/c10/
3. https://www.javatpoint.com/os-strategies-for-handling-deadlock
4. https://www.slideshare.net/RavalVijay/dining-philosopher-problem
5. https://www.youtube.com/watch?v=HHoB2t_B6MI
