#### Procedure to run the Simulator is as follows:
1. The experiment is to be performed by using the thinking and hungry button for each of the philosopher.
2. Initially all the philosophers are in the thinking state.
3. When any philosopher's state is to be changed to hungry state the hungry button is to pressed and the philosopher goes to the hungry state.
4. If the chopsticks are free for the philosopher i.e. if the chopstick to the right of him and the chopstick to the left of him is free, the philosopher goes to eating state else has to wait for his turn and hence goes to wait state.
